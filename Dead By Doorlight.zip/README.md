# Dead By Doorlight - Version 1.0
__Created By ProgramChimp and Bglicken__

# Description

### Are you dying of boredom spectating your "friend" who left you to die to the Bracken? Well now you can mess with him and make him believe he is schizo when you open and close doors around him!

*Developer Note: This mod has nothing to do with Dead By Daylight, we just thought the name was silly.*

# How To Use
### Typing "open/close" into the Text Chat while dead and spectating another player to open/close a door.

# Change Log

## [1.0]
### - Initial Public Release Version
### - Ability for Dead Players To Open/Close Doors

##### Last Updated: 1/21/24
